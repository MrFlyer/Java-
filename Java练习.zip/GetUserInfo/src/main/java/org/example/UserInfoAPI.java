package org.example;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.jboss.logging.Logger;
import org.keycloak.Config;
import org.keycloak.models.*;
import org.keycloak.services.resource.RealmResourceProvider;
import org.keycloak.services.resource.RealmResourceProviderFactory;

import java.util.Map;

public class UserInfoAPI implements RealmResourceProvider {

    private final KeycloakSession session;
    private Config.Scope config;
    public String UserSearchTitle = "userID";
    public String UserSearchField = "e6040";

    public static final Logger logger = Logger.getLogger(UserInfoAPI.class);


    public UserInfoAPI(KeycloakSession session,Config.Scope config) {
        this.session = session;
        this.config = config;
    }


    @Override
    public Object getResource() {
        return this;
    }

    @Override
    public void close() {

    }

    @GET
    @Path("userinfo")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUserInfo(){
        GetInfo user = new GetInfo(config);
        return Response.ok(Map.of("user-info",user.getUserInChoose(UserSearchTitle,UserSearchField,session))).build();
    }

}