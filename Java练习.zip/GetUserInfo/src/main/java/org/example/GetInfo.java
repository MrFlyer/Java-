package org.example;

import org.jboss.logging.Logger;
import org.keycloak.Config;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.KeycloakSessionFactory;
import org.keycloak.models.RealmModel;

import java.util.ArrayList;

public class GetInfo {

    private Logger logger = Logger.getLogger(GetInfo.class);
    public Config.Scope config;
    private String USER_INFO_REALM = "user-info-realm";
    public GetInfo(Config.Scope config){
        this.config = config;
    }
    public ArrayList<String> getUserInChoose(String UserTitle, String UserInfo, KeycloakSession session){
        ArrayList<String> list = new ArrayList<>();
//        KeycloakSession session = sessionFactory.create();
        String UserInfoRealm = config.get(USER_INFO_REALM);
        System.out.println("UserInfoRealm: "+UserInfoRealm);
        RealmModel realmModel = session.realms().getRealmByName("demo");
        System.out.println("111");
        session.users().searchForUserStream(realmModel,"")
                .filter(userModel -> {
                    try{
                        System.out.println("222");
                        return userModel.getFirstAttribute(UserTitle).equals(UserInfo);
                    } catch (Exception e){
                        logger.error(e);
                        return false;
                    }
                })
                .forEach((userModel) -> list.add(userModel.getUsername()));
        System.out.println(list);
        return list;
    }


}


//    KeycloakSession session = factory.create();
//        System.out.println(config.get("user-info-realm"));
//                GetInfo user = new GetInfo(config);
//                System.out.println("Init getinfo");
//                ArrayList<String> getUser = user.getUserInChoose(UserSearchTitle,UserSearchField,session);
//        logger.info(getUser);