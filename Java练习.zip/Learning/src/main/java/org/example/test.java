package org.example;

class CCC {
    int ccc = 10;
    int sum() {
        return ccc + 10;
    }
}
class DDD extends CCC{
    int ddd = 20;
    int sum(){
        return ddd + 20;
    }
}