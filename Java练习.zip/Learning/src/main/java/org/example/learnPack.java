package org.example;

class learnPack {
    String learnWhat;
    learnPack(){
        System.out.println("start learning ");
    }
    void learningPack() {
        System.out.println("hello");
    }
    void learningPack(String learnWhat){
        System.out.println(learnWhat);

    }
}
class buLearning extends learnPack{
    buLearning(){
        System.out.println("不学了捏");
    }
    void buxue(){
        System.out.println("开摆");
    }
}

class toumoLearning extends  learnPack{
    toumoLearning(){
        System.out.println("偷摸学捏");
    }

    void toumo(){
        System.out.println("在偷摸学");
    }
}
class learnChongzai{
    learnChongzai(){
        this("learn");
    }
    learnChongzai( String learnWhat){
        System.out.println(learnWhat);
    }
}