package org.example;

import org.keycloak.models.KeycloakSession;
import org.keycloak.timer.ScheduledTask;

public class test_timer implements ScheduledTask {
    @Override
    public void run(KeycloakSession session) {
        int a = 10000;
        System.out.println("a:" + a);
    }
}
