package org.example;

import com.google.auto.service.AutoService;
import org.keycloak.Config;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.KeycloakSessionFactory;
import org.keycloak.services.scheduled.ScheduledTaskRunner;
import org.keycloak.timer.ScheduledTask;
import org.keycloak.timer.TimerProvider;
import org.keycloak.timer.TimerProviderFactory;
import org.keycloak.timer.basic.BasicTimerProviderFactory;

import java.util.Timer;

@AutoService(TimerProviderFactory.class)
public class TaskDelet extends BasicTimerProviderFactory {

    private Config.Scope config;

    @Override
    public void init(Config.Scope config) {
        super.init(config);
        this.config = config;
    }

    @Override
    public void postInit(KeycloakSessionFactory factory) {
        KeycloakSession session = factory.create();

//        config = session.getKeycloakSessionFactory().();
        int getStartData = config.getInt("start-data", 0);
        int stopTime = config.getInt("stop-time", 300);
        System.out.println("start-data:" + getStartData);
        System.out.println("stop-time:" + stopTime);


        try{
            TimerProvider timer = session.getProvider(TimerProvider.class);
            timer.schedule(new ScheduledTaskRunner(factory,new test_timer(),getStartData),getStartData,"test-timer");
        }finally {
            session.close();
        }


    }


    @Override
    public String getId() {
        return "test-timer";
    }

}
