package org.example;

import jakarta.mail.Message;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.xml.soap.Detail;
import org.jboss.resteasy.specimpl.MultivaluedMapImpl;
import org.keycloak.Config;
import org.keycloak.authentication.FormAction;
import org.keycloak.authentication.FormActionFactory;
import org.keycloak.authentication.FormContext;
import org.keycloak.authentication.ValidationContext;
import org.keycloak.events.Details;
import org.keycloak.events.Errors;
import org.keycloak.forms.login.LoginFormsProvider;
import org.keycloak.models.*;
import org.keycloak.models.utils.FormMessage;
import org.keycloak.provider.ProviderConfigProperty;
import org.keycloak.services.messages.Messages;
import org.keycloak.services.validation.Validation;
import org.keycloak.userprofile.UserProfile;
import org.keycloak.userprofile.UserProfileContext;
import org.keycloak.userprofile.UserProfileProvider;
import org.keycloak.userprofile.ValidationException;

import java.lang.management.MemoryUsage;
import java.util.List;

public class RegistrationUserProfile implements FormAction, FormActionFactory {
    @Override
    public String getDisplayType() {
        return "RegistrationUserProfile";
    }

    @Override
    public String getReferenceCategory() {
        return null;
    }

    @Override
    public boolean isConfigurable() {
        return false;
    }

    private static AuthenticationExecutionModel.Requirement[] REQUIREMENT_CHOICES = {
            AuthenticationExecutionModel.Requirement.REQUIRED,
            AuthenticationExecutionModel.Requirement.ALTERNATIVE,
            AuthenticationExecutionModel.Requirement.DISABLED
    };

    @Override
    public AuthenticationExecutionModel.Requirement[] getRequirementChoices() {
        return REQUIREMENT_CHOICES;
    }

    @Override
    public boolean isUserSetupAllowed() {
        return false;
    }

    @Override
    public void buildPage(FormContext context, LoginFormsProvider form) {

    }

    @Override
    public void validate(ValidationContext context) {
        MultivaluedMap<String, String> formData = context.getHttpRequest().getDecodedFormParameters();

        context.getEvent().detail(Details.REGISTER_METHOD,"form");

        UserProfileProvider  profileProvider = context.getSession().getProvider(UserProfileProvider.class);
        UserProfile profile = profileProvider.create(UserProfileContext.REGISTRATION_PROFILE,formData);

        try{
            profile.validate();
        } catch (ValidationException e){
            List<FormMessage> errors = Validation.getFormErrorsFromValidation(e.getErrors());

            if (e.hasError(Messages.EMAIL_EXISTS,Messages.INVALID_EMAIL)){
                context.getEvent().detail(Details.EMAIL,profile.getAttributes().getFirstValue(UserModel.EMAIL));
            }
            if (e.hasError(Messages.EMAIL_EXISTS)){
                context.error(Errors.EMAIL_IN_USE);
            }else{
                context.error(Errors.INVALID_EMAIL);
            }
            context.validationError(formData, errors);
            return;
        }
        context.success();
    }

    @Override
    public void success(FormContext context) {
        UserModel userModel = context.getUser();

        UserProfileProvider profileProvider = context.getSession().getProvider(UserProfileProvider.class);
        profileProvider.create(UserProfileContext.REGISTRATION_PROFILE,
                context.getHttpRequest().getDecodedFormParameters(), userModel).update();
    }

    @Override
    public boolean requiresUser() {
        return false;
    }

    @Override
    public boolean configuredFor(KeycloakSession session, RealmModel realm, UserModel user) {
        return false;
    }

    @Override
    public void setRequiredActions(KeycloakSession session, RealmModel realm, UserModel user) {

    }

    @Override
    public String getHelpText() {
        return null;
    }

    @Override
    public List<ProviderConfigProperty> getConfigProperties() {
        return null;
    }

    @Override
    public FormAction create(KeycloakSession session) {
        return this;
    }

    @Override
    public void init(Config.Scope config) {

    }

    @Override
    public void postInit(KeycloakSessionFactory factory) {

    }

    @Override
    public void close() {

    }

    @Override
    public String getId() {
        return "RegistrationUserProfile";
    }
}
