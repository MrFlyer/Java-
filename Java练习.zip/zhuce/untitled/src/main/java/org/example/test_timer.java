package org.example;

import org.jboss.logging.Logger;
import org.keycloak.Config;
import org.keycloak.events.EventBuilder;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.models.UserModel;
import org.keycloak.services.scheduled.ScheduledTaskRunner;
import org.keycloak.timer.ScheduledTask;
import org.keycloak.userprofile.UserProfile;
import org.keycloak.userprofile.UserProfileContext;
import org.keycloak.userprofile.UserProfileProvider;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;

public class test_timer implements ScheduledTask {

    private Config.Scope config;
    public  String DELETE_USERS_BIRTH_DAY = "birth_years";
    public test_timer(Config.Scope config) {
        this.config = config;
    }
    private static final Logger logger = Logger.getLogger(ScheduledTaskRunner.class);
    public int a = 1;

    @Override
    public void run(KeycloakSession session) {

        String deletUserRealm = config.get("delet-user-realm","");
        int deletUserNum = config.getInt("delet-user-num",0);

        RealmModel realmModel = session.realms().getRealmByName(deletUserRealm);

        session.users().searchForUserStream(realmModel, "")
                .filter(user -> {
                    String userDateString = user.getFirstAttribute(DELETE_USERS_BIRTH_DAY);
                    try{
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                        LocalDate birthDay = LocalDate.parse(userDateString, formatter);
                        return birthDay.isBefore(LocalDate.of(2000,1,1));
                        //带！为保留2000以前，反之为保留2000以后
                    } catch (Exception e){
                        logger.error("birthday format error : " + e);
                        return false;
                    }
                })
                .limit(deletUserNum)
                .forEach((user) -> {
                String userDateString = user.getFirstAttribute(DELETE_USERS_BIRTH_DAY);
                try {
                    session.users().removeUser(realmModel, user);
                    logger.info("compiler delete user. " + " UserName: " + user.getUsername() + " UserBirthDay: " + user.getFirstAttribute(DELETE_USERS_BIRTH_DAY));
                } catch (Exception e) {
                    logger.warnv("User deletion failed. User ID: {0}, User Name: {1}.", user.getId(), user.getUsername());
                    logger.info("", e);
                }
                });

        logger.info("timer run " + a++);
    //        System.out.println("a:" + a++ );

    }
}
