package org.example;

import org.keycloak.Config;
import org.keycloak.authentication.FormAction;
import org.keycloak.authentication.FormActionFactory;
import org.keycloak.models.*;
import org.keycloak.provider.ProviderConfigProperty;
import org.keycloak.services.scheduled.ScheduledTaskRunner;
import org.keycloak.timer.TimerProvider;

import java.util.List;


public class RegistrationUserTask implements FormActionFactory {

    private Config.Scope config;

    @Override
    public FormAction create(KeycloakSession session) {
        return null;
    }

    @Override
    public void init(Config.Scope config) {
        this.config = config;
    }

    @Override
    public void postInit(KeycloakSessionFactory keycloakSessionFactory) {

        KeycloakSession session = keycloakSessionFactory.create();

        int timeLimit = config.getInt("time-limit", 1) * 1000;
        int timeDelay = config.getInt("time-delay", 3000);
        System.out.println("timeLimit: " + timeLimit);
        System.out.println("timeDelay :" + timeDelay);


        try{
            TimerProvider timer = session.getProvider(TimerProvider.class);
            timer.schedule(new ScheduledTaskRunner(keycloakSessionFactory,new test_timer(config),timeLimit),timeDelay,"test-timer");
        }finally {

            session.close();
        }

    }

    @Override
    public String getId() {
        return "ex-time";
    }

    @Override
    public String getDisplayType() {
        return null;
    }

    @Override
    public String getReferenceCategory() {
        return null;
    }

    @Override
    public boolean isConfigurable() {
        return false;
    }

    @Override
    public AuthenticationExecutionModel.Requirement[] getRequirementChoices() {
        return new AuthenticationExecutionModel.Requirement[0];
    }

    @Override
    public boolean isUserSetupAllowed() {
        return false;
    }


    @Override
    public String getHelpText() {
        return null;
    }

    @Override
    public List<ProviderConfigProperty> getConfigProperties() {
        return null;
    }

    @Override
    public void close() {

    }
}
